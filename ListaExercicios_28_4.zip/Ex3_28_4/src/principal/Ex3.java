package principal;

public class Ex3 {

	public static void main(String[] args) {
		//VERTICAL
		/*
		 
		for (int sequencia = 1; sequencia <= 20; sequencia ++) {
			System.out.println(sequencia);
			*/
		
		//HORIZONTAL
		
		for (int sequencia = 1; sequencia <= 20; sequencia ++) {
			System.out.print(sequencia + " ");
	}

	}
}