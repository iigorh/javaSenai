package principal;

public class Program {

	public static void main(String[] args) {
		
		// * 1- Fa�a um programa que mostre os �ndices de um array de 100 posi��es;

		int[] numeros = new int [100];
		
		for (int i = 0; i < numeros.length; i++) {
			
			System.out.println("Indices do array: "+ i);
		}
	}


		
	
}
